package tcp.nguyento.server;

import java.io.*;
import java.net.*;
import java.util.logging.*;

/*
    Đề bài: Viết Chương trình TCP Client/Server trong đó Client gửi lên Server một số
    nguyên dương n, Server nhận giá trị và trả về cho Client thông báo số đó có là số
    nguyên tố hay không và nếu là số nguyên tố thì trả về danh sách các số nguyên tố <= n
    và tổng các số nguyên tố đó.
 */
public class Server {

    ServerSocket serverSocket;
    Socket socket;
    DataInputStream dataInputStream;
    DataOutputStream dataOutputStream;

    public void SocketServer() {

        try {
            // Khởi tạo Server Socket, lắng nghe trên Port 2016
            serverSocket = new ServerSocket(2016);
            System.out.println("Server is Running . . .");

            // Chấp nhận kết nối khi có Client kết nối đến
            // Trả về đối tượng kiểu Socket
            socket = serverSocket.accept();
            System.out.println("Client successful connections!");
            // Lúc này Client và Server sẽ làm việc với nhau thông qua TCP Socket

            // Tạo dòng dữ liệu lấy về từ Socket
            dataInputStream = new DataInputStream(socket.getInputStream());
            // Nhận dữ liệu từ Socket mà Client đã gửi lên
            int a = dataInputStream.readInt();

            // Tạo dòng dữ liệu đẩy lên Socket
            dataOutputStream = new DataOutputStream(socket.getOutputStream());

            // Xử lý và gửi trả kết quả lên Socket để đưa tới Client
            if (Process.KiemTraNT(a)) {
                dataOutputStream.writeUTF("Là Nguyên tố \nDanh sách NT: " + Process.showNguyenTo(a));
            } else {
                dataOutputStream.writeUTF("Không là Nguyên tố");
            }

        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                dataInputStream.close();
                dataOutputStream.close();
                serverSocket.close();
                System.out.println("Server closed!");
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void main(String[] args) {
        Server server = new Server();
        server.SocketServer();
    }
}
