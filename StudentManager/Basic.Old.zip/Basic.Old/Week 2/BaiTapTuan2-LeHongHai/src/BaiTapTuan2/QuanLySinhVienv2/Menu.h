﻿#pragma once
using namespace std;

class Menu
{
public:
	// Các Phương thức hiển thị menu cho người dùng chọn
	void MenuChinh();
	void MenuThemSuaXoa();
	void MenuTimKiemSinhVien();
	void MenuSapXepSinhVien();
};

