﻿#pragma once
using namespace std;

class View {
public:
	void mainMenu();
	void updateMenu();
	void searchMenu();
	void sortMenu();
};

